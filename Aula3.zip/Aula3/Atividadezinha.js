// var Nome = "Thzinn";
// console.log(Nome)
// Nome = "ThzinnSF"
// console.log(Nome)

// var Nome2 = Nome + " Da " + "Testezin"


// var n1 = 5;
// var n2 = 5;


// var soma = n1 + n2 / n1 * n1 / n1 / n2 * n1 * n1 * n2 + (n1 + 100);

// document.write(soma)
// alert("Teste")

// alert("Hello world!")

// var Nome = "Thiago";
// Nome = "Thiago Soares";
// console.log(Nome)

// // 

// var Nteste = "Thiago";
// alert(Nteste + "Seja bem vindo!")

// var n1 = 20;
// var n2 = 30;

// var soma = n1 + n2;
// alert(soma)


// var nome = prompt("qual seu nome?")

// var sobrenome = prompt("qual seu sobrenome?")


// console.log("Olá " + nome + " " + sobrenome)

// document.write("<h1>Seja bem-vindo " + nome + " " + sobrenome + "</h1>")

// document.write("<h2>")


// var num1 = parseInt(num1)
// var num2 = parseInt(num2)
// var soma = parseInt(soma)
// var Nome = window.prompt("Digite seu nome.")


// document.write("<h1>Seja bem-vindo" + Nome + "</h1>")


// num1 = parseInt(window.prompt("Digite um número"))
// num2 = parseInt(window.prompt("Digite outro número"))



// soma = num1 + num2;




// console.log("A soma do seu num1: " + num1 + " + Num2: " + num2 + " = " + soma)
// alert(soma)


// PRIMEIRA QUESTÃO

// var nome = window.prompt("Digite seu nome")
// console.log(nome)

// var sobrenome = window.prompt("Agora seu sobrenome")

// console.log(sobrenome)

// document.write("<h2> Seu nomezin é " + nome + " " + sobrenome + "</h2>")

// QUESTÃO 2

// let num1 = parseInt(window.prompt("Digite um número ai fi d puta"))

// console.log(num1)

// if (num1 % 2 === 0) {
//     alert("O número " + num1 + " é par")


// }

// else {
//     alert("O número " + num1 + " é impar")
// }


// QUESTÃO 3

// let num1 = window.prompt("Digite um número")

// let num2 = window.prompt("Digite outro número")

// let quociente

// if (num2 != 0) {
//     quociente = (num1 / num2);
//     document.write("<h2> A quociente dos números é: " + quociente + "</h2>")
// } else {
//     document.write("<h2> Impossivu</h2>")
// }






